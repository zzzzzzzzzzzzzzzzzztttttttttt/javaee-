package com.hqyj.pojo;

import lombok.Data;

@Data
public class EmployerAge {
    private String name;
    private Integer value;
}
